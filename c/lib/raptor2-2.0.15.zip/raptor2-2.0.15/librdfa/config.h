/* Fake librdfa config.h - reads configuration from Raptor's config header */
#include <raptor_config.h>
