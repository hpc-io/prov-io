This is user contributed win32 configuration for building rasqal
using MS Windows development environments.

The latest files are the *.vcproj files for MS Visual Studio 8,
provided by John Barstow.

The *.dsp *.dsw files are older and from MS Developer Studio provided
by several prople.

The various project files assume that raptor have been installed or
compiled in sibling top level directories. See the rasqal.vcproj
(newest) or rasqal.dsp (older) files for the exact paths used, which
can be version-number dependant.

I do not test this configuration since I don't use Windows.  I am
happy to receive patches to fix things though.

Dave
2005-05-19
